# SnakeGame
simple snake game, just 150 line code  

![](http://www.xtutu.me/img/snake20160107105906.png) 
